import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IndexedDBService } from '../services/indexed-db.service';

@Component({
  selector: 'app-pedidos',
  templateUrl: './pedidos.page.html',
  styleUrls: ['./pedidos.page.scss'],
})
export class PedidosPage implements OnInit {
  pedidos: any[] = [];
  pedidosConcluidos: any[] = [];
  totalCarrinho: number = 0;
  taxaEntrega: number = 5.00;
  totalComTaxa: number = 0;

  constructor(
    private route: ActivatedRoute,
    private indexedDBService: IndexedDBService,
    private router: Router
  ) {}

  async ngOnInit() {
    await this.carregarDadosCarrinho(); // Carregar os dados ao iniciar a página
    await this.carregarPedidos(); // Carregar pedidos após os dados do carrinho
  }

  // Função para carregar os dados do carrinho do IndexedDB
  async carregarDadosCarrinho() {
    try {
      const dadosCarrinho = await this.indexedDBService.getItems(); // Modificado de getItem para getItems
      if (dadosCarrinho && dadosCarrinho.length > 0) {
     
        const carrinho = dadosCarrinho[0]; // Ajuste conforme a estrutura
        this.totalCarrinho = carrinho.totalCarrinho || 0;
        this.taxaEntrega = carrinho.taxaEntrega || 5.00;
        this.totalComTaxa = carrinho.totalComTaxa || 0;
      }

      console.log('Valores carregados do carrinho:', this.totalCarrinho, this.taxaEntrega, this.totalComTaxa);
    } catch (error) {
      console.error('Erro ao carregar os dados do carrinho:', error);
    }
  }

  // Carregar os pedidos do IndexedDB
  async carregarPedidos() {
    try {
      const itensCarrinho = await this.indexedDBService.getItems();
      console.log('Itens do carrinho:', itensCarrinho);

      this.pedidos = itensCarrinho.map(item => ({
        id: item.id,
        nome: item.name,
        status: 'Em Andamento',
        preco: parseFloat(item.price) || 0,
      }));

      this.totalCarrinho = this.pedidos.reduce((total, pedido) => total + (pedido.preco || 0), 0);
      this.totalComTaxa = this.totalCarrinho + this.taxaEntrega;

      console.log('Totais calculados:', this.totalCarrinho, this.totalComTaxa);
    } catch (error) {
      console.error('Erro ao carregar os pedidos:', error);
    }
  }

  // Confirmar a entrega de todos os pedidos
  confirmarEntregaDeTodos() {
    this.pedidos.forEach(pedido => {
      pedido.status = 'Concluído';
      this.pedidosConcluidos.push(pedido);
    });

    this.limparCarrinho();
  }

  goToPedidos() {
    this.router.navigateByUrl('/tabs/pedidos');
  }



  // Limpar o carrinho após confirmação
    limparCarrinho() {
    try {
      this.indexedDBService.clearItems();
      this.pedidos = [];
      this.totalCarrinho = 0;
      this.totalComTaxa = 0;
  
      // Salvar os dados atualizados do carrinho
       this.indexedDBService.setItem('carrinho', {
        totalCarrinho: this.totalCarrinho,
        taxaEntrega: this.taxaEntrega,
        totalComTaxa: this.totalComTaxa
      });
  
    } catch (error) {
      console.error('Erro ao limpar o carrinho:', error);
    }
  }

  // Função para voltar à página anterior
  voltar() {
    this.router.navigateByUrl('/tabs/tab3');
  }
}
